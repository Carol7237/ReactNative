import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator, TouchableOpacity, Button } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

export default function GamesList() {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigation = useNavigation();

  const fetchGames = async () => {
    setLoading(true);
    try {
      const userToken = await AsyncStorage.getItem('userToken');
      const response = await fetch('http://163.172.177.98:8081/game', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${userToken}`,
        },
      });
      const data = await response.json();
      if (response.status === 200) {
        setGames(data.games);
      } else {
        console.error('Failed to fetch games:', data);
      }
    } catch (error) {
      console.error('Error fetching games:', error);
    } finally {
      setLoading(false);
    }
  };

  const createGame = async () => {
    try {
      const userToken = await AsyncStorage.getItem('userToken');
      const response = await fetch('http://163.172.177.98:8081/game', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${userToken}`,
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      if (response.status === 200) {
        console.log('Game created successfully:', data);
        navigation.navigate('GameScreen', { gameId: data.id });
      } else {
        console.error('Failed to create game:', data);
      }
    } catch (error) {
      console.error('Error creating game:', error);
    }
  };

  const joinGame = async (gameId) => {
    try {
      const userToken = await AsyncStorage.getItem('userToken');
      const response = await fetch(`http://163.172.177.98:8081/game/join/${gameId}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${userToken}`,
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      if (response.status === 200) {
        console.log('Joined game successfully:', data);
        fetchGames(); 
        navigation.navigate('GameScreen', { gameId: data.id });
      } else {
        console.error('Failed to join game:', data);
      }
    } catch (error) {
      console.error('Error joining game:', error);
    }
  };

  useEffect(() => {
    fetchGames();
  }, []);

  if (loading) {
    return <ActivityIndicator size="large" color="#0000ff" style={styles.loadingIndicator} />;
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.createButtonContainer}>
        <TouchableOpacity style={styles.createButton} onPress={createGame}>
          <Text style={styles.createButtonText}>Create Game</Text>
        </TouchableOpacity>
      </View>
      {games.map((game, index) => (
        <View key={index} style={styles.gameContainer}>
          <Text style={styles.statusText}>Status: {game.status}</Text>
          <Text style={styles.emailText}>Player 1: {game.player1.email}</Text>
          <Text style={styles.emailText}>Player 2: {game.player2 ? game.player2.email : 'Waiting for player...'}</Text>
          {!game.player2 && (
            <TouchableOpacity style={styles.joinButton} onPress={() => joinGame(game.id)}>
              <Text style={styles.joinButtonText}>Join</Text>
            </TouchableOpacity>
          )}
        </View>
      ))}
      <View style={styles.refreshButtonContainer}>
        <TouchableOpacity style={styles.refreshButton} onPress={fetchGames}>
          <Text style={styles.refreshButtonText}>Refresh</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 20,
    paddingBottom: 50,
    backgroundColor: '#f0f8ff',
  },
  loadingIndicator: {
    marginTop: 20,
  },
  createButtonContainer: {
    marginHorizontal: 16,
    marginBottom: 20,
  },
  createButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
  createButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  gameContainer: {
    backgroundColor: '#ffffff',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
    borderLeftWidth: 6,
    borderLeftColor: '#4CAF50',
  },
  statusText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#333',
    textShadowColor: 'rgba(0, 0, 0, 0.1)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 1,
  },
  emailText: {
    fontSize: 16,
    marginBottom: 5,
    color: '#555',
  },
  joinButton: {
    marginTop: 10,
    backgroundColor: '#4CAF50',
    padding: 10,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
  joinButtonText: {
    color: 'white',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  refreshButtonContainer: {
    marginVertical: 50,
    paddingHorizontal: 16,
  },
  refreshButton: {
    backgroundColor: '#1E90FF',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
  refreshButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
