import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Button, ScrollView, Animated } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation, useRoute } from '@react-navigation/native';

const GRID_SIZE = 10;
const BOATS = [
  { id: 1, size: 2, orientation: 'horizontal', position: null },
  { id: 2, size: 2, orientation: 'horizontal', position: null },
  { id: 3, size: 2, orientation: 'horizontal', position: null },
  { id: 4, size: 2, orientation: 'horizontal', position: null },
  { id: 5, size: 3, orientation: 'horizontal', position: null },
  { id: 6, size: 3, orientation: 'horizontal', position: null },
  { id: 7, size: 3, orientation: 'horizontal', position: null },
  { id: 8, size: 4, orientation: 'horizontal', position: null },
  { id: 9, size: 4, orientation: 'horizontal', position: null },
  { id: 10, size: 6, orientation: 'horizontal', position: null },
];

export default function CreateGameScreen() {
  const [selectedBoat, setSelectedBoat] = useState(null);
  const [boats, setBoats] = useState(BOATS);
  const [board, setBoard] = useState(Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(null)));
  const route = useRoute();
  const { gameId } = route.params;
  const navigation = useNavigation();

  const handleSelectBoat = (boatId) => {
    setSelectedBoat(boatId);
  };

  const handlePlaceBoat = (row, col) => {
    if (selectedBoat !== null) {
      const boat = boats.find(b => b.id === selectedBoat);

      let canPlace = true;
      if (boat.orientation === 'horizontal') {
        if (col + boat.size > GRID_SIZE) {
          canPlace = false;
        } else {
          for (let i = 0; i < boat.size; i++) {
            if (board[row][col + i] !== null && board[row][col + i] !== selectedBoat) {
              canPlace = false;
              break;
            }
          }
        }
      } else {
        if (row + boat.size > GRID_SIZE) {
          canPlace = false;
        } else {
          for (let i = 0; i < boat.size; i++) {
            if (board[row + i][col] !== null && board[row + i][col] !== selectedBoat) {
              canPlace = false;
              break;
            }
          }
        }
      }

      if (canPlace) {
        const newBoard = board.map(row => row.slice());
        boats.forEach(b => {
          if (b.position) {
            for (let i = 0; i < b.size; i++) {
              if (b.orientation === 'horizontal') {
                newBoard[b.position.row][b.position.col + i] = null;
              } else {
                newBoard[b.position.row + i][b.position.col] = null;
              }
            }
          }
        });

        const newBoats = boats.map(b => {
          if (b.id === selectedBoat) {
            return { ...b, position: { row, col } };
          }
          return b;
        });
        setBoats(newBoats);

        newBoats.forEach(b => {
          if (b.position) {
            for (let i = 0; i < b.size; i++) {
              if (b.orientation === 'horizontal') {
                newBoard[b.position.row][b.position.col + i] = b.id;
              } else {
                newBoard[b.position.row + i][b.position.col] = b.id;
              }
            }
          }
        });
        setBoard(newBoard);
        setSelectedBoat(null);
      }
    }
  };

  const handleRotateBoat = () => {
    if (selectedBoat !== null) {
      const boat = boats.find(b => b.id === selectedBoat);

      const { row, col } = boat.position || {};
      let canRotate = true;
      if (row !== undefined && col !== undefined) {
        if (boat.orientation === 'horizontal') {
          if (row + boat.size > GRID_SIZE) {
            canRotate = false;
          } else {
            for (let i = 0; i < boat.size; i++) {
              if (board[row + i][col] !== null && board[row + i][col] !== selectedBoat) {
                canRotate = false;
                break;
              }
            }
          }
        } else {
          if (col + boat.size > GRID_SIZE) {
            canRotate = false;
          } else {
            for (let i = 0; i < boat.size; i++) {
              if (board[row][col + i] !== null && board[row][col + i] !== selectedBoat) {
                canRotate = false;
                break;
              }
            }
          }
        }
      }

      if (canRotate) {
        const newBoard = board.map(row => row.slice());
        boats.forEach(b => {
          if (b.position) {
            for (let i = 0; i < b.size; i++) {
              if (b.orientation === 'horizontal') {
                newBoard[b.position.row][b.position.col + i] = null;
              } else {
                newBoard[b.position.row + i][b.position.col] = null;
              }
            }
          }
        });

        const newBoats = boats.map(b => {
          if (b.id === selectedBoat) {
            return { ...b, orientation: b.orientation === 'horizontal' ? 'vertical' : 'horizontal' };
          }
          return b;
        });
        setBoats(newBoats);

        newBoats.forEach(b => {
          if (b.position) {
            for (let i = 0; i < b.size; i++) {
              if (b.orientation === 'horizontal') {
                newBoard[b.position.row][b.position.col + i] = b.id;
              } else {
                newBoard[b.position.row + i][b.position.col] = b.id;
              }
            }
          }
        });
        setBoard(newBoard);
      } else if (boat.position === null) {
        const newBoats = boats.map(b => {
          if (b.id === selectedBoat) {
            return { ...b, orientation: b.orientation === 'horizontal' ? 'vertical' : 'horizontal' };
          }
          return b;
        });
        setBoats(newBoats);
      }
    }
  };

  const renderGrid = () => {
    return board.map((row, rowIndex) => (
      <View key={rowIndex} style={styles.row}>
        {row.map((col, colIndex) => (
          <TouchableOpacity
            key={colIndex}
            style={[
              styles.cell,
              { borderLeftWidth: colIndex === 0 ? 4 : 1 },
              { borderTopWidth: rowIndex === 0 ? 4 : 1 },
              { borderRightWidth: colIndex === GRID_SIZE - 1 ? 4 : 1 },
              { borderBottomWidth: rowIndex === GRID_SIZE - 1 ? 4 : 1 },
              col !== null && styles.occupiedCell,
              col !== null && selectedBoat === col && styles.selectedCell,
            ]}
            onPress={() => col === null ? handlePlaceBoat(rowIndex, colIndex) : handleSelectBoat(col)}
          />
        ))}
      </View>
    ));
  };

  const renderBoats = () => {
    return boats.filter(boat => boat.position === null).map((boat) => (
      <TouchableOpacity
        key={boat.id}
        style={[
          styles.boat,
          selectedBoat === boat.id && styles.selectedBoat,
          { width: boat.orientation === 'horizontal' ? boat.size * 30 : 30 },
          { height: boat.orientation === 'vertical' ? boat.size * 30 : 30 },
        ]}
        onPress={() => handleSelectBoat(boat.id)}
      >
        <Text style={styles.boatText}>{boat.size}x</Text>
      </TouchableOpacity>
    ));
  };

  const startBattle = async () => {
    if (gameId) {
      const ships = boats
        .filter(boat => boat.position !== null)
        .map(boat => ({
          x: String.fromCharCode(65 + boat.position.row),
          y: boat.position.col + 1,
          size: boat.size,
          direction: boat.orientation.toUpperCase() === 'HORIZONTAL' ? 'VERTICAL' : 'HORIZONTAL',
        }));

      const requestBody = { ships };
      console.log('Request body:', requestBody);

      try {
        const userToken = await AsyncStorage.getItem('userToken');
        const response = await fetch(`http://163.172.177.98:8081/game/${gameId}`, {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${userToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
        });

        const data = await response.json();
        console.log('Server response:', data);
        if (response.ok) {
          console.log('Battle started successfully:', data);
          navigation.navigate('Attack', { gameId });
        } else {
          console.error('Failed to start battle:', data);
        }
      } catch (error) {
        console.error('Error starting battle:', error);
      }
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.boardContainer}>
        {renderGrid()}
      </View>
      <TouchableOpacity style={styles.rotateButton} onPress={handleRotateBoat}>
        <Text style={styles.buttonText}>Rotate Boat</Text>
      </TouchableOpacity>
      <View style={styles.boatsContainer}>
        {renderBoats()}
      </View>
      <TouchableOpacity style={styles.startBattleButton} onPress={startBattle}>
        <Text style={styles.buttonText}>Start Battle</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    alignItems: 'center',
    backgroundColor: '#f0f8ff',
    paddingVertical: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 2,
  },
  boardContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: GRID_SIZE * 35,
    height: GRID_SIZE * 35,
    borderWidth: 4,
    borderColor: '#00008B',
    borderRadius: 10,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
  row: {
    flexDirection: 'row',
  },
  cell: {
    width: 35,
    height: 35,
    borderColor: '#87CEEB',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f8ff',
  },
  occupiedCell: {
    backgroundColor: '#87CEFA',
  },
  selectedCell: {
    backgroundColor: '#4682B4',
    transform: [{ scale: 1.1 }],
  },
  boatsContainer: {
    marginTop: 20,
    width: '80%',
  },
  boat: {
    marginVertical: 5,
    backgroundColor: 'blue',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    padding: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
  selectedBoat: {
    backgroundColor: '#4682B4',
    transform: [{ scale: 1.1 }],
  },
  boatText: {
    color: 'white',
    fontSize: 12,
  },
  rotateButton: {
    marginTop: 20,
    backgroundColor: '#4CAF50',
    padding: 10,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
  startBattleButton: {
    marginTop: 20,
    backgroundColor: '#FF4500',
    padding: 10,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
