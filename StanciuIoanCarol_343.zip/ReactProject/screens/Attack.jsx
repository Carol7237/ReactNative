import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Button } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRoute } from '@react-navigation/native';

const GRID_SIZE = 10;

export default function BattleScreen() {
  const [selectedCell, setSelectedCell] = useState(null);
  const [board, setBoard] = useState(Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(null)));
  const route = useRoute();
  const { gameId } = route.params;

  const handleCellPress = (row, col) => {
    if (board[row][col] !== 'hit') {
      if (selectedCell && selectedCell.row === row && selectedCell.col === col) {
        setSelectedCell(null);
      } else {
        setSelectedCell({ row, col });
      }
    }
  };

  const handleAttack = async () => {
    if (selectedCell) {
      const x = String.fromCharCode(65 + selectedCell.row);
      const y = selectedCell.col + 1;
      const requestBody = { x, y };

      console.log('Request body:', requestBody);

      try {
        const userToken = await AsyncStorage.getItem('userToken');
        const response = await fetch(`http://163.172.177.98:8081/game/strike/${gameId}`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${userToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
        });

        const data = await response.json();
        console.log('Server response:', data);
        if (response.ok) {
          console.log('Attack successful:', data);
          if (data.result) {
            const newBoard = board.map(row => row.slice());
            newBoard[selectedCell.row][selectedCell.col] = 'hit';
            setBoard(newBoard);
            setSelectedCell(null);
          }
        } else {
          console.error('Failed to attack:', data);
        }
      } catch (error) {
        console.error('Error during attack:', error);
      }
    }
  };

  const renderGrid = () => {
    return Array(GRID_SIZE).fill(null).map((_, rowIndex) => (
      <View key={rowIndex} style={styles.row}>
        {Array(GRID_SIZE).fill(null).map((_, colIndex) => (
          <TouchableOpacity
            key={colIndex}
            style={[
              styles.cell,
              { borderLeftWidth: colIndex === 0 ? 4 : 1 },
              { borderTopWidth: rowIndex === 0 ? 4 : 1 },
              { borderRightWidth: colIndex === GRID_SIZE - 1 ? 4 : 1 },
              { borderBottomWidth: rowIndex === GRID_SIZE - 1 ? 4 : 1 },
              board[rowIndex][colIndex] === 'hit' && styles.hitCell,
              selectedCell && selectedCell.row === rowIndex && selectedCell.col === colIndex && styles.selectedCell,
            ]}
            onPress={() => handleCellPress(rowIndex, colIndex)}
          />
        ))}
      </View>
    ));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Attack</Text>
      <View style={styles.boardContainer}>
        {renderGrid()}
      </View>
      <TouchableOpacity style={styles.attackButton} onPress={handleAttack}>
        <Text style={styles.buttonText}>Attack</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#f0f8ff',
    paddingVertical: 20,
  },
  text: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 2,
  },
  boardContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: GRID_SIZE * 35,
    height: GRID_SIZE * 35,
    borderWidth: 4,
    borderColor: '#00008B',
    borderRadius: 10,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
  row: {
    flexDirection: 'row',
  },
  cell: {
    width: 35,
    height: 35,
    borderColor: '#87CEEB',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f8ff',
  },
  hitCell: {
    backgroundColor: 'red',
  },
  selectedCell: {
    backgroundColor: '#4682B4',
    transform: [{ scale: 1.1 }],
  },
  attackButton: {
    marginTop: 20,
    backgroundColor: '#FF4500',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
