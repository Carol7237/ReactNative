import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StyleSheet } from 'react-native';

import Register from './screens/Register';
import Login from './screens/Login'; 
import Profile from './screens/Profile';
import GamesList from './screens/GamesList';
import JoinSuccessPage from './screens/JoinSuccessPage';
import CreateGameScreen from './screens/CreateGameScreen';
import Attack from './screens/Attack';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Register" component={Register} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Profile" component={Profile} />
        <Stack.Screen name="GamesList" component={GamesList} />
        <Stack.Screen name="Game" component={JoinSuccessPage} />
        <Stack.Screen name="GameScreen" component={CreateGameScreen} />
        <Stack.Screen name="Attack" component={Attack} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}



